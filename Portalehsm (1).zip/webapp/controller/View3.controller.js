sap.ui.define([
	"sap/ui/core/mvc/Controller" ,	"sap/ui/core/UIComponent" ,
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
], function(Controller,  UIComponent,MessageToast , Filter, FilterOperator ,  MessageBox ) {
	"use strict";

	return Controller.extend("Portalehsm.controller.View3", {
		onInit : function(oEvent){
	//	opage = new sap.m.Page();
	//	opage.addStyleClass("bgimage");
	var arr=[];
	var OtableId = this.getView().byId("table");
	var oModel  = new sap.ui.model.json.JSONModel();
	oModel.setData(arr);
	OtableId.setModel(oModel);
		
		
			
		//	this.getView().addStyleClass("bgimage");
			
		},
			navpress : function(oevent){
		 history.go(-1);	
		},	 

		Ppress: function(event){
				var arr=[];
	var OtableId = this.getView().byId("table");
//	var oModel  = new sap.ui.model.json.JSONModel();
//	oModel.setData(arr);
//	OtableId.setModel(oModel);
			
			window.console.log("presss");
		//	var OTab = this.getView().byId("table").getModel().getProperty("/");
			var plant=this.getView().byId("plant").getValue();
		//	var mrpcontroller = this.getView().byId("mrpcontroller").getValue();
			
				var url = "/sap/opu/odata/sap/ZPORTAL_EHSM_PORTALS_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(url,true);
			var uri = "?$filter=Planplant eq'"+plant+"'";
			var status,Plant,Name,list;
			window.console.log(uri);
			
			oModel.read("/ListIncSet"+uri+"&$format=json",{
				context : null,
				urlParameters:null,
				async :false,
				success : function(oData,Responces){
					window.console.log(oData);
					list = oData["results"];
					status = oData["results"][0]["Message"];
					window.console.log(typeof(status));
					window.console.log(list)
					;
					
				//	OTab.push(list);
					window.console.log("data");
				//	window.console.log(OTab);
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(list);
				OtableId.setModel(oModel);
					
					 
					
					
					
				}
			} );
			if(status === "success"){
				
			
			//this.getView().byId("table").getModel().setProperty("/",OTab[0]);
			}
			else{
				MessageToast.show("Enter Valid Input ")
				;
			}
			}
	,
				onSearch: function (oEvent) {
			// add filter for search
			var afilter=[];
		var sValue = oEvent.getParameter("query");
		window.console.log(sValue);
		if(sValue)
		{
			afilter.push(new Filter("Recn",FilterOperator.Contains,sValue));
		}
			// new Filter("Planordernum", FilterOperator.Contains, sValue);
		//	var oBinding = oEvent.getSource().getBinding("items");
		//	oBinding.filter([oFilter]);
			var otable = this.byId("table");
			var oBinding = otable.getBinding("items");
			oBinding.filter(afilter);
			
		},
		onselectchange : function(oevent){
			
		},
		onselectionchange : function(ovent){
				var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
		var r =	this.byId("table")._aSelectedPaths[0].split("/")[1];
		var value = this.byId("table").getModel().aBindings.at(0).oList[r].Recn;
		//	var oselect = ovent.getSource().getParent();
		//	var obind = oselect.getBindingContext().getObject();
		//	var id = obind.PlannedorderNum;
			MessageBox.confirm("Get Details of "+value,{
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function (sAction) {
					if (sAction === "OK"){
						window.console.log("ok is pressed");
						
								Orouter.navTo("View5",{
									"Recordnumber" : value
								}); 
					}
				}
			});
		window.console.log(r);
			window.console.log(value);
		}
		
		
		// onPress: function (OEvent) {
		// 	var username ,password;
		// 	username = this.getView().byId("employeeid").getValue();
		// 	password = this.getView().byId("password").getValue();
		// 	var url = "/sap/opu/odata/sap/ZPORTAL_SF_PORTAL_SRV/";
		// 	var oModel = new sap.ui.model.odata.ODataModel(url,true);
		// 	var uri = "Username='"+ username +"',Password='" +password+ "'";
		// 	var status,Plant,Name;
		// 	window.console.log(uri);
			
		// 	oModel.read("/LoginSet("+uri+")?$format=json",{
		// 		context : null,
		// 		urlParameters:null,
		// 		async :false,
		// 		success : function(oData,Responces){
		// 			window.console.log(oData);
		// 			status = oData["Message"];
		// 			window.console.log(typeof(status));
					
					
					
					
		// 		}
		// 	} );
		// 	if(status === "login sucess"){
		// 		window.console.log("login success");
		// 		var mssg="Login successful";
		// 	//	MessageToast.show(mssg);
		// 		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// 		oRouter.navTo("View2");
				
				 
				
				
		// 	}
		// 	else{
		// 	//	window.console.log("invalid login"); 
		// 	//	 MessageBox.alert("invalid ");	
			
			
				 
		// 	}
			 
			
			
			
			
			
		
		
			
		// }
		
	});
});