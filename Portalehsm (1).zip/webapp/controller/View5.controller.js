sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	
], function(Controller , MessageToast , Filter, FilterOperator) {
	"use strict";

	return Controller.extend("Portalehsm.controller.View5", {
		navpress : function(oevent){
		 history.go(-1);	
		},
		onInit : function(oEvent){
				this.getView().byId("recordnum").setValue("");
			var NAme="name";
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			window.console.log(oRouter);
			var val = oRouter._oRouter._prevMatchedRequest.split("/")[1];
			window.console.log(val);
			window.console.log("value is "+ val);
	//	window.console.log(this.getRouter().getRoute("View").attachMatched(this._onRouteMatched, this);
		//	this.getView().byId("nameText").setText(NAme);
	//	opage = new sap.m.Page();
	//	opage.addStyleClass("bgimage");
	// var arr=[];
	// var OtableId = this.getView().byId("table");
	// var oModel  = new sap.ui.model.json.JSONModel();
	// oModel.setData(arr);
	// OtableId.setModel(oModel);
	this.byId("recordnum").setValue(val);
	
	if(val!=""){
		this.Ppress();
	}
	
		
		
			
		//	this.getView().addStyleClass("bgimage");
			
		},

		Ppress: function(event){
	 			var arr=[];
	var OtableId = this.getView().byId("table");
//	var oModel  = new sap.ui.model.json.JSONModel();
//	oModel.setData(arr);
//	OtableId.setModel(oModel);
			
			window.console.log("presss");
			//var OTab = this.getView().byId("table").getModel().getProperty("/");
			var plant=this.getView().byId("recordnum").getValue();
			var mrpcontroller;
				var url ="/sap/opu/odata/sap/ZPORTAL_EHSM_PORTALS_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(url,true);
			var uri = "Recordnum='"+plant+ "'";
			var status,Plant,Name,list;
			window.console.log(uri);
			
			oModel.read("/IncDetailsgetSet("+uri+")?$format=json",{
				context : null,
				urlParameters:null,
				async :false,
				success : function(oData,Responces){
					window.console.log(oData);
					list = oData["results"];
					window.console.log(typeof(status));
					window.console.log(list)
					;
					
				
				arr.push(oData);	
				//	OTab.push(oData);
					window.console.log("data");
				//	window.console.log(OTab);
				//	window.console.log(status);
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(arr);
				OtableId.setModel(oModel);
					 
					
					
					
				}
			} );
			
				// var uri1 = "Planordernum='"+plant+ "'";
				// var list2;
				// var arr1=[];
				
				// var mnum ,mgenral, mguid, mrparea;
				// var mrpcontroller , reservnum;
				// var prodplant;
				// var ordertype , totalq ;
				// var status2;
	// 				var OformId = this.getView().byId("formdata");
	// var oModelf  = new sap.ui.model.json.JSONModel();
	// oModelf.setData(arr1);
	// OformId.setModel(oModelf);
	// var OTab1 = this.getView().byId("formdata").getModel().setProperty("/");
				
				// window.console.log(uri1);
			// 		oModel.read("/planorderdetailsSet("+uri1+")?$format=json",{
			// 	context : null,
			// 	urlParameters:null,
			// 	async :false,
			// 	success : function(oData,Responces){
			// 		window.console.log(oData);
			// 		list2 = oData["results"];
			// 		mnum = oData["Material"];
			// 		mguid= oData["MaterialGuid"];
			// 		mgenral=oData["MaterialExternal"];
			// 		mrparea = oData["MrpArea"];
			// 		mrpcontroller = oData["MrpController"];
			// 		reservnum=oData["ReservNo"];
			// 		ordertype = oData["OrderType"];
			// 		totalq = oData["TotalPlordQty"];
			// 		prodplant = oData["ProdPlant"];
			// 		status2 = oData["Type"];
			// 		//window.console.log(typeof(status));
			// 		window.console.log(list2)
			// 		;
					
					
					
			// 		window.console.log("data");
			// 	//	window.console.log(OTab1[0]);
			// 		window.console.log(status , mrparea ,mguid , mrpcontroller);
					
			// 		// this.getView().bindElement(list2); 
					
					
					
					
			// 	}
			// } );
				
			if( arr.length >0){
			
			// this.getView().byId("table").getModel().setProperty("/",OTab[0]);
			// 	this.getView().byId("nameText").setText(mnum);
			// 		this.getView().byId("matguid").setText(mguid);
			// 			this.getView().byId("Mrparea").setText(mrparea);
			// 				this.getView().byId("mrpcontroller").setText(mrpcontroller);
			// 					this.getView().byId("reservno").setText(reservnum);
			// 						this.getView().byId("otype").setText(ordertype);
			// 							this.getView().byId("qual").setText(totalq);
			// 						this.getView().byId("prodplant").setText(prodplant);
				
			}
			else{
				MessageToast.show("Enter Valid Input ")
				;
			}
			
	// 		},
	// 			onSearch: function (oEvent) {
	// 		// add filter for search
	// 	var sValue = oEvent.getParameter("tables");
	// 	window.console.log(sValue);
	// 		var oFilter = new Filter("Planordernum", FilterOperator.Contains, sValue);
	// 		var oBinding = oEvent.getSource().getBinding("items");
	// 		oBinding.filter([oFilter]);
		},
		onselectchange : function(oevent){
			
		}
		
		
		// onPress: function (OEvent) {
		// 	var username ,password;
		// 	username = this.getView().byId("employeeid").getValue();
		// 	password = this.getView().byId("password").getValue();
		// 	var url = "/sap/opu/odata/sap/ZPORTAL_SF_PORTAL_SRV/";
		// 	var oModel = new sap.ui.model.odata.ODataModel(url,true);
		// 	var uri = "Username='"+ username +"',Password='" +password+ "'";
		// 	var status,Plant,Name;
		// 	window.console.log(uri);
			
		// 	oModel.read("/LoginSet("+uri+")?$format=json",{
		// 		context : null,
		// 		urlParameters:null,
		// 		async :false,
		// 		success : function(oData,Responces){
		// 			window.console.log(oData);
		// 			status = oData["Message"];
		// 			window.console.log(typeof(status));
					
					
					
					
		// 		}
		// 	} );
		// 	if(status === "login sucess"){
		// 		window.console.log("login success");
		// 		var mssg="Login successful";
		// 	//	MessageToast.show(mssg);
		// 		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// 		oRouter.navTo("View2");
				
				 
				
				
		// 	}
		// 	else{
		// 	//	window.console.log("invalid login"); 
		// 	//	 MessageBox.alert("invalid ");	
			
			
				 
		// 	}
			 
			
			
			
			
			
		
		
			
		// }
		
	});
});