sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	
], function(Controller , MessageToast , Filter, FilterOperator ,  MessageBox) {
	"use strict";
	var oTable;
	var View;
	var cities;
	var jsonchennai,jsondubai,jsonooty,jsonlondon;
	

	return Controller.extend("Portalehsm.controller.View8", {
		onInit : function(oEvent){
	//	opage = new sap.m.Page();
	//	opage.addStyleClass("bgimage");
	var arr=[];
//	var OtableId = this.getView().byId("table");
	// var oModel  = new sap.ui.model.json.JSONModel();
	// oModel.setData(arr);
//	OtableId.setModel(oModel);
var oModel5 = new sap.ui.model.json.JSONModel({
			"city":[{
				"name":"Chennai"
			},
			{
				"name":"ooty"
			},
			{
				"name":"Dubai"
			}
			,
			{
				"name":"London"
			}
			]	
}); 
this.byId("city").setModel(oModel5);
		
		jQuery.sap.require("jquery.sap.storage");
	var  oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
	
	// oStorage.put("Chennai",jsonchennai);
	var localdata = oStorage.get("Chennai");
	var localdatadubai=oStorage.get("Dubai");
	var localdataooty = oStorage.get("ooty");
	var localdataLondon = oStorage.get("London");
	window.console.log(localdata);
	window.console.log(localdatadubai);
	window.console.log(localdataooty);
	window.console.log(localdataLondon);
	var on = window.navigator.onLine;
	
	window.console.log(on);
	
	
			
		//	this.getView().addStyleClass("bgimage");
			
		},
		navpress : function(oevent){
		 history.go(-1);	
		},

		Ppress: function(event){
				var arr=[];
//	var OtableId = this.getView().byId("table");
//	var oModel  = new sap.ui.model.json.JSONModel();
//	oModel.setData(arr);
//	OtableId.setModel(oModel);
			
			window.console.log("presss");
		//	var OTab = this.getView().byId("table").getModel().getProperty("/");
		var recn =this.getView().byId("recn").getValue(); 
			var plant=this.getView().byId("plant").getValue();
			var validfrom = this.getView().byId("validfrom").getValue();
			var validto = this.getView().byId("validto").getValue();
			var type   = this.getView().byId("type").getValue();
			var createdby = this.getView().byId("createdby").getValue();
			var eventdecs = this.getView().byId("edescription").getValue();
			var eventdate = this.getView().byId("eventdate").getValue();
		//	var mrparea = this.getView().byId("mrparea").getValue();
		var lang = this.byId("lang").getValue();
		var location= this.byId("fucloc").getValue();
			
		//	var mrpcontroller = this.getView().byId("mrpcontroller").getValue();
		
		var eqnum=this.getView().byId("eqnum").getValue();
			var eqdescription = this.getView().byId("eqdescription").getValue();
			var invresult = this.getView().byId("invresult").getValue();
			
			var acclocation=this.getView().byId("acclocation").getValue();
			var accdesc = this.getView().byId("accdescription").getValue();
			var workarea = this.getView().byId("workarea").getValue();
			
				var damagetype = this.getView().byId("dtype").getValue();
			
				var url = "/sap/opu/odata/sap/ZPORTAL_EHSM_PORTALS_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(url,true);
			//var uri = "(Recn='"+recn+"')";
			var status,Plant,Name,list,token; 
			var planorder, parsedate , parsedate2,parsedate1;
				var timeofset = new Date(0).getTimezoneOffset()*60*1000;
		var convert = sap.ui.core.format.DateFormat.getDateInstance({pattern : "MM/dd/yyyy"});
		var parsedate = convert.parse(validfrom).getTime() - timeofset;
		parsedate="\/Date("+parsedate+")\/";
	//		var timeofset = new Date(0).getTimezoneOffset()*60*1000;
	//	var convert = sap.ui.core.format.DateFormat.getDateInstance({pattern : "MM/dd/yyyy"});
		var parsedate1 = convert.parse(validto).getTime() - timeofset;
		parsedate1="\/Date("+parsedate1+")\/";
			//var timeofset = new Date(0).getTimezoneOffset()*60*1000;
		//var convert = sap.ui.core.format.DateFormat.getDateInstance({pattern : "MM/dd/yyyy"});
		var parsedate2 = convert.parse(eventdate).getTime() - timeofset;
		parsedate2="\/Date("+parsedate2+")\/";
		
	
		//	window.console.log(uri);
		var requestorderheader = {
			"Recn" : recn,
			"Aclocdesc" : accdesc ,
			"Acloc" : acclocation,
			"Crnam" : createdby,	
			"Dmtype" : damagetype,	
			"Evdesc" : eventdecs,
			"Eqdesc" : eqdescription,
			"Equnr" : eqnum,
			"Evdat" : parsedate2,
			"Invresult" : invresult,
			"Iaplant" : plant,
			"Iatype" : type,
			"Valfr" : parsedate,
			"Valto" : parsedate1,
			"Recntwah" : workarea,
			"Mtnlangu" : lang,
			"Tplnr" : location

		
		};
		window.console.log(requestorderheader) ;
		// oModel.read('/CreatePlanorderSet',
  //null,
  //null,
  //false,
  //function(oData, oResponse) {
  //	window.console.log(oData);
  //	window.console.log(oResponse);
  //token = oResponse.headers['x-csrf-token'];
  //});
  var recordnum="";
  
  //oModel.setHeaders(
  //{
                      
  //"Content-Type": "application/json"
  //});
  //"X-CSRF-Token": token });
  
		oModel.update("/IncUpdateSet(Recn='"+recn+"')", requestorderheader, null,
			function(Odata , Responces){
				window.console.log(Responces);
				MessageBox.success("Update success");
				window.console.log(Odata);
				recn="1";
				// recordnum = Odata["Recn"];
				
			});
			
			// oModel.read("/ListSet"+uri+"&$format=json",{
			// 	context : null,
			// 	urlParameters:null,
			// 	async :false,
			// 	success : function(oData,Responces){
			// 		window.console.log(oData);
			// 		list = oData["results"];
			// 		status = oData["results"][0]["Type"];
			// 		window.console.log(typeof(status));
			// 		window.console.log(list)
			// 		;
					
				//	OTab.push(list);
					window.console.log("data");
				//	window.console.log(OTab);
			//	var oModel = new sap.ui.model.json.JSONModel();
			//	oModel.setData(list);
			//	OtableId.setModel(oModel);
					
					 
					
					
					
				
			if(recordnum === ""){
				
		//	MessageBox.success("Incident Created "+recordnum);
			//this.getView().byId("table").getModel().setProperty("/",OTab[0]);
			}
			else{
				MessageToast.show("Enter Valid Input ")
				;
			}
		}
			


	,
				onSearch: function (oEvent) {
			// add filter for search
			var afilter=[];
		var sValue = oEvent.getParameter("query");
		window.console.log(sValue);
		if(sValue)
		{
			afilter.push(new Filter("PlannedorderNum",FilterOperator.Contains,sValue));
		}
			// new Filter("Planordernum", FilterOperator.Contains, sValue);
		//	var oBinding = oEvent.getSource().getBinding("items");
		//	oBinding.filter([oFilter]);
			var otable = this.byId("table");
	                         
			var oBinding = otable.getBinding("items");
			oBinding.filter(afilter);
			
		},
		onselectchange : function(oevent){
			
		},
		onselectionchange : function(ovent){
				var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
		var r =	this.byId("table")._aSelectedPaths[0].split("/")[1];
		var value = this.byId("table").getModel().aBindings.at(0).oList[r].PlannedorderNum;
		//	var oselect = ovent.getSource().getParent();
		//	var obind = oselect.getBindingContext().getObject();
		//	var id = obind.PlannedorderNum;
			MessageBox.confirm("Get Details of"+value,{
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function (sAction) {
					if (sAction === "OK"){
						window.console.log("ok is pressed");
						
								Orouter.navTo("View6",{
									"PlannedorderNum" : value
								}); 
					}
				}
			});
		window.console.log(r);
			window.console.log(value);
		},
		
		
		// onPress: function (OEvent) {
		// 	var username ,password;
		// 	username = this.getView().byId("employeeid").getValue();
		// 	password = this.getView().byId("password").getValue();
		// 	var url = "/sap/opu/odata/sap/ZPORTAL_SF_PORTAL_SRV/";
		// 	var oModel = new sap.ui.model.odata.ODataModel(url,true);
		// 	var uri = "Username='"+ username +"',Password='" +password+ "'";
		// 	var status,Plant,Name;
		// 	window.console.log(uri);
			
		// 	oModel.read("/LoginSet("+uri+")?$format=json",{
		// 		context : null,
		// 		urlParameters:null,
		// 		async :false,
		// 		success : function(oData,Responces){
		// 			window.console.log(oData);
		// 			status = oData["Message"];
		// 			window.console.log(typeof(status));
					
					
					
					
		// 		}
		// 	} );
		// 	if(status === "login sucess"){
		// 		window.console.log("login success");
		// 		var mssg="Login successful";
		// 	//	MessageToast.show(mssg);
		// 		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// 		oRouter.navTo("View2");
				
				 
				
				
		// 	}
		// 	else{
		// 	//	window.console.log("invalid login"); 
		// 	//	 MessageBox.alert("invalid ");	
			
			
				 
		// 	}
			 
			
			_formatDate: function(date) {
			var d = new Date(date),
				month = '' + (d.getMonth() + 1),
				day = '' + d.getDate(),
				year = d.getFullYear();

			if (month.length < 2) {
				month = '0' + month;
			}
			if (day.length < 2){
				day = '0' + day;	
			} 
			return [ day,month,year].join('/');
		},

		_mapResults: function(results) {
	
			var aForecastResults = [];
			var todayinfo = [];
			todayinfo.push(results.current);
			todayinfo.push(results.timezone);
			this.byId("timezone").setValue(results.timezone);
			window.console.log(todayinfo); 
		var	OtableId = this.byId("table");
			var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(todayinfo);
			OtableId.setModel(oModel);
					 
		
			for (var i = 1; i < results.daily.length; i++) {
				var oTemp = results.daily[i].temp;
				var date = this._formatDate(results.daily[i].dt * 1000);
			
				aForecastResults.push({
					date: date,
					tempDay: oTemp.day,
					tempEve: oTemp.eve,
					humidity: results.daily[i].humidity,
					dew_point: results.daily[i].dew_point,
					wind_speed: results.daily[i].wind_speed,
					description : results.daily[i].weather[0].description
				});
				                
			}
			window.console.log("hello");
			window.console.log(aForecastResults);
			// if(cities == "Chennai" ){
			// 				jsonchennai= aForecastResults;
			// 				window.console.log("saved");
			// 				// window.console.log(results);
							
			// 					jQuery.sap.require("jquery.sap.storage");
			// 				var  oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
	
			// 						oStorage.put("Chennai",jsonchennai);
							
							
			// 			}
			// 				if(cities == "Dubai" ){
			// 			jsondubai= aForecastResults;
			// 				window.console.log("saved");
			// 				// window.console.log(results);
							
			// 					jQuery.sap.require("jquery.sap.storage");
			// 				var  oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
	
			// 						oStorage.put("Dubai",jsondubai);
							
							
			// 			}
			var tableModel = new sap.ui.model.json.JSONModel();
			tableModel.setData({
				daily:aForecastResults
			});
			oTable = this.getView().byId("daily");
			oTable.setModel(tableModel);
		},

		_loadForecast: function(lat,lon) {
		
			var oView = this.getView();
			// var oParams = {
			// 	q: "Chennai",  // Get the weather in london
			// 	units: "metric", 
			// 	cnt: 16,  // get weather for the next 16 days
			// 	appid: "add your api key" // replace with your API key
			// 	// mode: "json"  // get it in JSON format 
			// };
			var oParams1={
				lat: lat,
				lon: lon,
				units: "metric", 
				appid: "c68e73f8d3d5aeae6b064633b41572cf" //  API key
			};
			
			
			
			// var sUrl = "/OpenWeather/data/2.5/forecast/daily";
			// var sUrl="/OpenWeather/data/2.5/weather";
			var sUrl=	"/OpenWeather/data/2.5/onecall";
		
			oView.setBusy(true);

			var self = this;

			$.get(sUrl, oParams1)
				.done(function(results) {
					oView.setBusy(false);
					window.console.log(results);
					if(cities == "Chennai"){
						jsonchennai = results;
						
								jQuery.sap.require("jquery.sap.storage");
							var  oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
	
									oStorage.put("Chennai",jsonchennai);
									window.console.log("Chennaidatasaved");
						
					}
					if(cities == "Dubai"){
						jsondubai = results;
						
								jQuery.sap.require("jquery.sap.storage");
							var  oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
	
									oStorage.put("Dubai",jsondubai);
									window.console.log("Dubaidatasaved");
						
					}
					if(cities == "London"){
						jsonlondon = results;
						
								jQuery.sap.require("jquery.sap.storage");
							var  oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
	
									oStorage.put("London",jsonlondon);
									window.console.log("datasaved");
						
					}
					if(cities == "ooty"){
						jsonooty = results;
						
								jQuery.sap.require("jquery.sap.storage");
							var  oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
	
									oStorage.put("ooty",jsonooty);
									window.console.log("ootydatasaved");
						
					}
					
					window.console.log("the result");
					self._mapResults(results);
				})
				.fail(function(err) {
					oView.setBusy(false);
					if (err !== undefined) {
						var oErrorResponse = $.parseJSON(err.responseText);
						sap.m.MessageToast.show(oErrorResponse.message, {
							duration: 6000
						});
					} else {
						sap.m.MessageToast.show("Unknown error!");
					}
				});
		},
		onCity: function(oEvent){
			// View.byId("search").setValue("");
			var oView = this.getView();
			var sQuery = oEvent.getParameter("query");
			
		
				var location = this.byId("city").getValue();
				window.console.log(location); 
			window.console.log(sQuery);
			// cities= sQuery;
				sQuery=location;
				cities = sQuery;
				var online = window.navigator.onLine;
				if(online == false){
						jQuery.sap.require("jquery.sap.storage");
							var  oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
						var result=	oStorage.get(sQuery);
							// this._mapResults(result);
							if(result == null){
								MessageToast.show("citiy is not saved in database");
							}
							else{
								this._mapResults(result);
							}
					
				}
				else{
			
			
			var sUrl=	"/OpenWeather//geo/1.0/direct";
		
			oView.setBusy(true);

			var self = this;
			
			var City=oView.byId("city");
			
			
			var oParams={
				q:sQuery,
				appid: "a11a0e4775a74d7b5781f642c4a50b0c" // api key
			};
			
			
			$.get(sUrl, oParams)
				.done(function(results) {
					oView.setBusy(false);
					// window.console.log(results);
					if(results.length!==0){
						City.setValue(results[0].name);
						self._loadForecast(results[0].lat,results[0].lon);
						// if(sQuery == "Chennai" ){
						// 	jsonchennai= results;
						// 	window.console.log("saved");
						// 	window.console.log(results);
							
						// 		jQuery.sap.require("jquery.sap.storage");
						// 	var  oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
	
						// 			oStorage.put("Chennai",jsonchennai);
							
							
						// }
						// 	if(sQuery == "Dubai" ){
						// jsondubai= results;
						// 	window.console.log("saved");
						// 	window.console.log(results);
							
						// 		jQuery.sap.require("jquery.sap.storage");
						// 	var  oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
	
						// 			oStorage.put("Dubai",jsondubai);
							
							
						// }
					}
					else{
						sap.m.MessageToast.show("Unknown city! '"+sQuery+"' ");
					}
				})
				.fail(function(err) {
					oView.setBusy(false);
					if (err !== undefined) {
						var oErrorResponse = $.parseJSON(err.responseText);
						sap.m.MessageToast.show(oErrorResponse.message, {
							duration: 6000
						});
					} else {
						sap.m.MessageToast.show("Unknown error!");
					}
				});
			
			
		}
		},
	onCityclear: function(){
			jQuery.sap.require("jquery.sap.storage");
							var  oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
	oStorage.clear();
	MessageToast.show("Success");
		
	}
			
		
	
			
			
			
		
		
			
		// }
		
	});
});