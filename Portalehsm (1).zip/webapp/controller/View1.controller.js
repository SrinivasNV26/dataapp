sap.ui.define([
	"sap/ui/core/mvc/Controller" ,	"sap/ui/core/UIComponent" ,
	"sap/m/MessageToast",
], function(Controller,  UIComponent,MessageToast  ) {
	"use strict";

	return Controller.extend("Portalehsm.controller.View1", {
	onInit : function(oEvent){
	//	opage = new sap.m.Page();
	//	opage.addStyleClass("bgimage");
		
		
			
		//	this.getView().addStyleClass("bgimage");
			
		},
		
		onPress: function (OEvent) 
				//var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			 //	oRouter.navTo("View2");
		
		{	
			window.console.log("presses");
			
			// var formid = this.byId("SimpleFormToolbar");
			// window.console.log(formid);
			// formid.setBusy(true);
			
			// setTimeout(function(oevent){
			// formid.setBusy(false);
			// },8000);
			
			
			var username ,password;
			username = this.getView().byId("employeeid").getValue();
			password = this.getView().byId("password").getValue();
			var url = "/sap/opu/odata/sap/ZPORTAL_EHSM_PORTALS_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(url,true);
			var uri = "Username='"+ username +"',Password='" +password+ "'";
			var status,Plant,Name;
			window.console.log(uri);
			
			oModel.read("/LoginSet("+uri+")?$format=json",{
				context : null,
				urlParameters:null,
				async :false,
				success : function(oData,Responces){
					window.console.log(oData);
					status = oData["Message"];
					window.console.log(typeof(status));
					
					
					
					
				}
			} );
			if(status === "success"){
				window.console.log("login success");
				var mssg="Login successful";
				MessageToast.show(mssg);
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("View2");
				
				 
				
				
			}
			else{
				MessageToast.show("Invliad login");
			//	window.console.log("invalid login"); 
			//	 MessageBox.alert("invalid ");	
			
			
				 
			}
			 
			
			
			
			
			
		
		
			
		}
		
	});
});