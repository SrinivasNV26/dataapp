sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"Portalehsm/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("Portalehsm.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
				this.getRouter().initialize();
				this.renderRecastChatbot();
		}		,
		renderRecastChatbot: function() {
		if (!document.getElementById("cai-webchat")) {
			var url="cdn.cai.tools.sap/webchat/webchat.js";
			var  s = document.createElement("script");
		//	document.createElement("script");
	 			 s.setAttribute("id", "cai-webchat");
			 s.setAttribute("src","https://"+url);
				 document.body.appendChild(s);
		}
		s.setAttribute("channelId", "3b57ff3f-290e-458c-b548-479daf9dd419");
		s.setAttribute("token", "19ea9b92e21948b3aba04a09667445b2");
}
	});
});