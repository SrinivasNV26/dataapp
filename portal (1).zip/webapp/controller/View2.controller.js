sap.ui.define([
	"sap/ui/core/mvc/Controller",
		"sap/ui/core/UIComponent"
	
], function(Controller, UIComponents ) {
	"use strict";

	return Controller.extend("sfportalportal.controller.View2", {

		Ppress: function(event){
			window.console.log("presss");
			
			var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View3");
			
		},
		Prodpress: function(event){
			window.console.log("presss");
			
			var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View4");
			
		},
		Lpress: function(event){
			var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View5");
			
			
		},
		Plandetailspress:function(ovent){
						var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View6");
			
			
		},
		Proddetailspress : function(oevent){
				var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View7");
			
		},
		PPpress : function(oevent){
				var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View10");
			
			
		},
		LDpress : function(oevent){
				var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View8");
		},
		
		logout : function(oevent){
				var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
				Orouter.navTo("View1");
			
		}
		,
		navpress : function(oevent){
		 history.go(-1);	
		},
		
		// onPress: function (OEvent) {
		// 	var username ,password;
		// 	username = this.getView().byId("employeeid").getValue();
		// 	password = this.getView().byId("password").getValue();
		// 	var url = "/sap/opu/odata/sap/ZPORTAL_SF_PORTAL_SRV/";
		// 	var oModel = new sap.ui.model.odata.ODataModel(url,true);
		// 	var uri = "Username='"+ username +"',Password='" +password+ "'";
		// 	var status,Plant,Name;
		// 	window.console.log(uri);
			
		// 	oModel.read("/LoginSet("+uri+")?$format=json",{
		// 		context : null,
		// 		urlParameters:null,
		// 		async :false,
		// 		success : function(oData,Responces){
		// 			window.console.log(oData);
		// 			status = oData["Message"];
		// 			window.console.log(typeof(status));
					
					
					
					
		// 		}
		// 	} );
		// 	if(status === "login sucess"){
		// 		window.console.log("login success");
		// 		var mssg="Login successful";
		// 	//	MessageToast.show(mssg);
		// 		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// 		oRouter.navTo("View2");
				
				 
				
				
		// 	}
		// 	else{
		// 	//	window.console.log("invalid login"); 
		// 	//	 MessageBox.alert("invalid ");	
			
			
				 
		// 	}
			 
			
			
			
			
			
		
		
			
		// }
		
	});
});