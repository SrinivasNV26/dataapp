sap.ui.define([
	"sap/ui/core/mvc/Controller"
	,	"sap/ui/core/UIComponent" ,
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	
], function(Controller,  UIComponent,MessageToast , Filter, FilterOperator ,  MessageBox ) {
	"use strict";
	var title ="Info ";
	var lots;
	var inspopernum;

	return Controller.extend("Portalquality.controller.View5", {
		onInit : function(oEvent){
	//	opage = new sap.m.Page();
	//	opage.addStyleClass("bgimage");
	// var arr=[];
	// var OtableId = this.getView().byId("table");
	// var oModel  = new sap.ui.model.json.JSONModel();
	// oModel.setData(arr);
	// OtableId.setModel(oModel);
	this.getView().byId("lot").setValue("");
			var NAme="name";
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			window.console.log(oRouter);
			var val = oRouter._oRouter._prevMatchedRequest.split("/")[1];
			window.console.log(val);
			var val2 = oRouter._oRouter._prevMatchedRequest.split("/")[2];
			window.console.log(val2);
			window.console.log("value is "+ val);
			this.byId("lot").setValue(val);
			this.byId("operationnum").setValue(val2);
			this.byId("title").setText(title);
		
		if (val != "" &&  val2 != ""){
			this.Ppress();
		}
			
		//	this.getView().addStyleClass("bgimage");
			
		},
		navpress : function(oevent){
		 history.go(-1);	
		},	 

		Ppress: function(event){
				var arr=[];
	var OtableId = this.getView().byId("table");
	var OtableId1 = this.getView().byId("table1");
	var OtableId2 = this.getView().byId("table2");
	var OtableId3 = this.getView().byId("table3");
//	var oModel  = new sap.ui.model.json.JSONModel();
//	oModel.setData(arr);
//	OtableId.setModel(oModel);
			
			window.console.log("presss");
			var generalDetail=[];
			var stockdetail=[];
			var usage=[];
			var opertion=[];
			var listtask=[];
		//	var OTab = this.getView().byId("table").getModel().getProperty("/");
			var lot=this.getView().byId("lot").getValue();
			var opnum = this.byId("operationnum").getValue();
			lots=lot;
			inspopernum = opnum;
		//	var mrpcontroller = this.getView().byId("mrpcontroller").getValue();
			
				var url = "/sap/opu/odata/sap/ZPORTALS_QM_PORTAL_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(url,true);
			var uri = "?$filter=Insplot eq'"+lot+"' and Inspoper eq '"+opnum+"'";
			var status,Plant,Name,list;
			window.console.log(uri);
			
			oModel.read("/ItSpecificationSet"+uri+"&$format=json",{
				context : null,
				urlParameters:null,
				async :false,
				success : function(oData,Responces){
					window.console.log(oData);
					list = oData["results"];
					status = oData["results"][0]["Plant"];
					window.console.log(typeof(status));
					window.console.log(list)
					;
					// var data ={
					// 	"Insplotnum" : list[0]["Insplot"],
					//  "plant" : list[0]["Plant"]	,
					//  "type" : list[0][]
					// };
				//	OTab.push(list);
					window.console.log("data");
				//	window.console.log(OTab);
			// 	generalDetail.push(list[0]);
			// window.console.log(generalDetail); 
			 	var oModel = new sap.ui.model.json.JSONModel();
			 	oModel.setData(list);
				OtableId.setModel(oModel);
			// 	OtableId1.setModel(oModel);
			// 	OtableId2.setModel(oModel);
			// 		var oModel2 = new sap.ui.model.json.JSONModel();
			// 	oModel2.setData(list);
				
			// 	OtableId3.setModel(oModel2);
					
				}
			} );
				
					oModel.read("/InsplotOpdetailsSet(Insplot='"+lot+"',Inspoper='"+opnum+"')"+"?$format=json",{
				context : null,
				urlParameters:null,
				async :false,
				success : function(oData,Responces){
					window.console.log(oData);
					list = oData["results"];
				//	status = oData["results"][0]["Plant"];
					window.console.log(typeof(status));
					window.console.log(list)
					;
					
					title = "Inspection in Plant "+oData["Plant"]+" and Operations is "+oData["TxtOper"]+" ";
					window.console.log(title);
					
					// var data ={
					// 	"Insplotnum" : list[0]["Insplot"],
					//  "plant" : list[0]["Plant"]	,
					//  "type" : list[0][]
					// };
				//	OTab.push(list);
					window.console.log("data");
				//	window.console.log(OTab);
			// 	generalDetail.push(list[0]);
			// window.console.log(generalDetail); 
			 //	var oModel = new sap.ui.model.json.JSONModel();
			 //	oModel.setData(list);
				// OtableId.setModel(oModel);
			// 	OtableId1.setModel(oModel);
			// 	OtableId2.setModel(oModel);
			// 		var oModel2 = new sap.ui.model.json.JSONModel();
			// 	oModel2.setData(list);
				
			// 	OtableId3.setModel(oModel2);
					
				}
			} );
				this.getView().byId("title").setText(title);
				
			oModel.read("/ItSingleresultSet"+uri+"&$format=json",{
				context : null,
				urlParameters:null,
				async :false,
				success : function(oData,Responces){
					window.console.log(oData);
					list = oData["results"];
					status = oData["results"][0]["Plant"];
					window.console.log(typeof(status));
					window.console.log(list)
					;
					// var data ={
					// 	"Insplotnum" : list[0]["Insplot"],
					//  "plant" : list[0]["Plant"]	,
					//  "type" : list[0][]
					// };
				//	OTab.push(list);
					window.console.log("data single");
				//	window.console.log(OTab);
			// 	generalDetail.push(list[0]);
			// window.console.log(generalDetail); 
// 			for(var i = 0 ; i < list.length ; i++){
// 			 		 //var myDate = new Date(jsonDate.match(/\d+/)[0] * 1);
//     			// 				   myDate.add(4).hours();  //using {date.format.js} to add time to compensate for timezone offset
//       // 					 myDate.format(); //using {date.format.js} plugin to format :: EDM FORMAT='yyyy-MM-ddTHH:mm:ss'
// 			 	//	window.console.log(new sap.ui.model.type.DateTime(list[i]["StartDate"]));
// 			 	//		var convert = sap.ui.core.format.DateFormat.getDateInstance({pattern : "MM/dd/yyyy"});
// 		// var parsedate = convert.parse(li);
		
// 		window.console.log(list[i]["InspDate"].split("(")[1].split(")")[0]);
// 		var dateseconds = list[i]["InspDate"].split("(")[1].split(")")[0];
// 		var date = new Date(parseFloat(dateseconds));
// var dateString = date.getDate() + "/" + date.getMonth() +1+ "/" + date.getFullYear();
// 		window.console.log(dateString);
// 		list[i]["InspDate"]=dateString;
// 			}
			 	var oModel2 = new sap.ui.model.json.JSONModel();
			 	oModel2.setData(list);
				OtableId2.setModel(oModel2);
			// 	OtableId1.setModel(oModel);
			// 	OtableId2.setModel(oModel);
			// 		var oModel2 = new sap.ui.model.json.JSONModel();
			// 	oModel2.setData(list);
				
			// 	OtableId3.setModel(oModel2);
					
				}
			} );
			
			
			
			
				oModel.read("/ItCharlistSet"+uri+"&$format=json",{
				context : null,
				urlParameters:null,
				async :false,
				success : function(oData,Responces){
					window.console.log(oData);
					list = oData["results"];
					status = oData["results"][0]["Plant"];
					window.console.log(typeof(status));
					window.console.log(list)
					;
					// var data ={
					// 	"Insplotnum" : list[0]["Insplot"],
					//  "plant" : list[0]["Plant"]	,
					//  "type" : list[0][]
					// };
				//	OTab.push(list);
					window.console.log("data");
				//	window.console.log(OTab);
			// 	generalDetail.push(list[0]);
			// window.console.log(generalDetail); 
			 	var oModel1 = new sap.ui.model.json.JSONModel();
// 			 	for(var i = 0 ; i < list.length ; i++){
// 			 		 //var myDate = new Date(jsonDate.match(/\d+/)[0] * 1);
//     			// 				   myDate.add(4).hours();  //using {date.format.js} to add time to compensate for timezone offset
//       // 					 myDate.format(); //using {date.format.js} plugin to format :: EDM FORMAT='yyyy-MM-ddTHH:mm:ss'
// 			 	//	window.console.log(new sap.ui.model.type.DateTime(list[i]["StartDate"]));
// 			 	//		var convert = sap.ui.core.format.DateFormat.getDateInstance({pattern : "MM/dd/yyyy"});
// 		// var parsedate = convert.parse(li);
		
// 		window.console.log(list[i]["StartDate"].split("(")[1].split(")")[0]);
// 		var dateseconds = list[i]["StartDate"].split("(")[1].split(")")[0];
// 		var date = new Date(parseFloat(dateseconds));
// var dateString = date.getDate() + "/" + date.getMonth() +1+ "/" + date.getFullYear();
// 		window.console.log(dateString);
// 		list[i]["StartDate"]=dateString;
// 		// window.console.log(convert.parse(list[i]["StartDate"]));
// {
// "Insplot" : "01000002861",
// "Inspoper" : "0010",
// "Inspsample" : "000000",
// "Inspchar" : "0010",
// "Evaluation" : "A",
// "Evaluated" : "X",
// "MeanValue" : "12.300",
// "ResNo" : "0001",
// "ResValue" : "12.300"

// }
// {

// "Number" : "010000002861",
// "Code" : "A",
// "CodeGroup" "01",
// "ForceCompletion" : "X",
// "Plant" : "SA01"
// "SelectedSet" : "01"
// "StockPosting" : "X"




// }
// 			 		}
			 	oModel1.setData(list);
			 	
			 	
				OtableId1.setModel(oModel1);
			// 	OtableId1.setModel(oModel);
			// 	OtableId2.setModel(oModel);
			// 		var oModel2 = new sap.ui.model.json.JSONModel();
			// 	oModel2.setData(list);
				
			// 	OtableId3.setModel(oModel2);
					
				}
			} );
			
			
			
			
			
			if(status === list[0]["Plant"] ){
				
			
			//this.getView().byId("table").getModel().setProperty("/",OTab[0]);
			}
			else{
				MessageToast.show("Enter Valid Input ")
				;
			}
			}
	,
				onSearch: function (oEvent) {
			// add filter for search
			var afilter=[];
		var sValue = oEvent.getParameter("query");
		window.console.log(sValue);
		if(sValue)
		{
			afilter.push(new Filter("Insplot",FilterOperator.Contains,sValue));
		}
			// new Filter("Planordernum", FilterOperator.Contains, sValue);
		//	var oBinding = oEvent.getSource().getBinding("items");
		//	oBinding.filter([oFilter]);
			var otable = this.byId("table");
	                         
			var oBinding = otable.getBinding("items");
			oBinding.filter(afilter);
			
		},
		onselectchange : function(oevent){
			
		},
		onselectionchange : function(ovent){
				var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
		var r =	this.byId("table3")._aSelectedPaths[0].split("/")[1];
		var value = this.byId("table3").getModel().aBindings.at(0).oList[r].Inspoper;
		//	var oselect = ovent.getSource().getParent();
		//	var obind = oselect.getBindingContext().getObject();
		//	var id = obind.PlannedorderNum;
			MessageBox.confirm("Get Details of "+value,{
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function (sAction) {
					if (sAction === "OK"){
						window.console.log("ok is pressed");
						
								Orouter.navTo("View5",{
									"Recordnumber" : value
								}); 
					}
				}
			});
		window.console.log(r);
			window.console.log(value);
		},
		Precordresult: function(ovent){
				var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
		// var r =	this.byId("table3")._aSelectedPaths[0].split("/")[1];
		// var value = this.byId("table3").getModel().aBindings.at(0).oList[r].Inspoper;
		//	var oselect = ovent.getSource().getParent();
		//	var obind = oselect.getBindingContext().getObject();
		//	var id = obind.PlannedorderNum;
			MessageBox.confirm("Result Record for "+lots  ,{
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function (sAction) {
					if (sAction === "OK"){
						window.console.log("ok is pressed");
						
								Orouter.navTo("View6",{
									"insplotnum" : lots,
									"inspopernum" : inspopernum
								}); 
					}
				}
			});
		// window.console.log(r);
		// 	window.console.log(value);
		}
		
		
		// onPress: function (OEvent) {
		// 	var username ,password;
		// 	username = this.getView().byId("employeeid").getValue();
		// 	password = this.getView().byId("password").getValue();
		// 	var url = "/sap/opu/odata/sap/ZPORTAL_SF_PORTAL_SRV/";
		// 	var oModel = new sap.ui.model.odata.ODataModel(url,true);
		// 	var uri = "Username='"+ username +"',Password='" +password+ "'";
		// 	var status,Plant,Name;
		// 	window.console.log(uri);
			
		// 	oModel.read("/LoginSet("+uri+")?$format=json",{
		// 		context : null,
		// 		urlParameters:null,
		// 		async :false,
		// 		success : function(oData,Responces){
		// 			window.console.log(oData);
		// 			status = oData["Message"];
		// 			window.console.log(typeof(status));
					
					
					
					
		// 		}
		// 	} );
		// 	if(status === "login sucess"){
		// 		window.console.log("login success");
		// 		var mssg="Login successful";
		// 	//	MessageToast.show(mssg);
		// 		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// 		oRouter.navTo("View2");
				
				 
				
				
		// 	}
		// 	else{
		// 	//	window.console.log("invalid login"); 
		// 	//	 MessageBox.alert("invalid ");	
			
			
				 
		// 	}
			 
			
			
			
			
			
		
		
			
		// }
		
	});
});