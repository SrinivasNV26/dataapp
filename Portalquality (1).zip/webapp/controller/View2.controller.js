sap.ui.define([
	"sap/ui/core/mvc/Controller" ,	"sap/ui/core/UIComponent" ,
	"sap/m/MessageToast",
], function(Controller,  UIComponent,MessageToast  ) {
	"use strict";

	return Controller.extend("Portalquality.controller.View2", {
		
		onInit: function(){
		 var api= "https://"	;
		//  window.console.log(api);
		//  var xhttp = new XMLHttpRequest();
		// xhttp.open('GET',api);	
		// 	xhttp.send();
		// 	window.console.log(xhttp.response);
		var oModels= new sap.ui.model.json.JSONModel();
	//	oModels.setData(, [bMerge])
	oModels.loadData(api+"api.openweathermap.org/data/2.5/weather?q=London,uk&APPID=a11a0e4775a74d7b5781f642c4a50b0c");
	window.console.log(oModels); 
 
 
		// window.addEventListener('load',function(){
		// fetch(api+"api.openweathermap.org/data/2.5/weather?q=London,uk&APPID=a11a0e4775a74d7b5781f642c4a50b0c")
  //      .then( function(ovent){
  //      	window.console.log(ovent);
  //      });
		// });
		
		;
		 
		}
		,

		Ppress: function(event){
			window.console.log("presss");
			
			var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View3");
			
		},
		Prodpress: function(event){
			window.console.log("presss");
			
			var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View6");
			
		},
		Lpress: function(event){
			var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View5");
			
			
		},
		Plandetailspress:function(ovent){
						var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View4");
			
			
		},
		Upress : function(oevent){
				var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View7");
			
		},
		PPpress : function(oevent){
				var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View6");
			
			
		},
		LDpress : function(oevent){
				var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View8");
		},
		
		Wpress : function(ovent){
			var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
			Orouter.navTo("View7");
			
		},
		
		logout : function(oevent){
				var Orouter = sap.ui.core.UIComponent.getRouterFor(this);
				Orouter.navTo("View1");
			
		}
		,
		navpress : function(oevent){
		 history.go(-1);	
		},
			onItemClose: function (oEvent) {
		MessageToast.show("closepressed");
	
		
			}		
		// onPress: function (OEvent) {
		// 	var username ,password;
		// 	username = this.getView().byId("employeeid").getValue();
		// 	password = this.getView().byId("password").getValue();
		// 	var url = "/sap/opu/odata/sap/ZPORTAL_SF_PORTAL_SRV/";
		// 	var oModel = new sap.ui.model.odata.ODataModel(url,true);
		// 	var uri = "Username='"+ username +"',Password='" +password+ "'";
		// 	var status,Plant,Name;
		// 	window.console.log(uri);
			
		// 	oModel.read("/LoginSet("+uri+")?$format=json",{
		// 		context : null,
		// 		urlParameters:null,
		// 		async :false,
		// 		success : function(oData,Responces){
		// 			window.console.log(oData);
		// 			status = oData["Message"];
		// 			window.console.log(typeof(status));
					
					
					
					
		// 		}
		// 	} );
		// 	if(status === "login sucess"){
		// 		window.console.log("login success");
		// 		var mssg="Login successful";
		// 	//	MessageToast.show(mssg);
		// 		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// 		oRouter.navTo("View2");
				
				 
				
				
		// 	}
		// 	else{
		// 	//	window.console.log("invalid login"); 
		// 	//	 MessageBox.alert("invalid ");	
			
			
				 
		// 	}
			 
			
			
			
			
			
		
		
			
		// }
		
	});
});